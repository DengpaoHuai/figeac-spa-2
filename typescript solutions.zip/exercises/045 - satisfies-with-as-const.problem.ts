import { Equal, Expect } from "../helpers";

/*
Toujours avec satisfies mais avec un truc en plus, comment faire marche le code ici ?
*/

const routes = {
  "/": {
    component: "Home",
  },
  "/about": {
    component: "About",
    // @ts-expect-error
    search: "?foo=bar",
  },
} as const satisfies Record<
  string,
  {
    component: string;
  }
>;

// @ts-expect-error
routes["/"].component = "About";

const demo = {
  demo1: {
    demo2: "test2",
  },
};

Object.freeze(demo);

demo.demo1.demo2 = "test";

type tests = [
  Expect<Equal<(typeof routes)["/"]["component"], "Home">>,
  Expect<Equal<(typeof routes)["/about"]["component"], "About">>
];
