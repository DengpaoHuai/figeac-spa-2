type Event = {
  message: string;
};

/*
Comment corriger l'erreur ici ?
*/
const processUserMap = (eventMap: Map<string, Event>) => {
  let error = eventMap.get("error");
  if (error) {
    const message = error.message;

    throw new Error(message);
  }
};
