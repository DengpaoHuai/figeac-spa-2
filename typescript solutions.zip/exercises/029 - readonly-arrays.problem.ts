/* 
Même problème que dans l'exercice précédent, mais cette fois-ci avec un tableau.
Indice : je ne vous ai pas tout dit :)
*/

function printNames(names: string[]) {
  for (const name of names) {
    console.log(name);
  }

  // @ts-expect-error
  names.push("John");

  // @ts-expect-error
  names[0] = "Billy";
}
