import { Equal, Expect } from "../helpers";

/*
Il y a de la duplication de code ici. Comment transformer un type en générique 
pour éviter la duplication de code ?

*/

type ErrorShape = {
  error: {
    message: string;
  };
};
type UserData = {
  id: string;
  name: string;
  email: string;
};

type PostData = {
  title: string;
  body: string;
  id: string;
};

type TShape<T> =
  | {
      data: T;
    }
  | ErrorShape;

// TESTS

type tests = [
  Expect<
    Equal<
      TShape<UserData>,
      | {
          data: {
            id: string;
            name: string;
            email: string;
          };
        }
      | {
          error: {
            message: string;
          };
        }
    >
  >,
  Expect<
    Equal<
      TShape<PostData>,
      | {
          data: {
            id: string;
            title: string;
            body: string;
          };
        }
      | {
          error: {
            message: string;
          };
        }
    >
  >
];
