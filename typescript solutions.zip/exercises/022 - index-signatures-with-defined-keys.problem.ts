/* 
Avec des index signatures, je peux définir les clés possibles de mon objet.
Ici, je veux pouvoir ajouter des notes obligatoires pour les matières suivantes:
- math
- english
- science

Et je veux pouvoir également ajouter des notes facultatives pour les autres matières.
*/

type Scores = {
  [subject: string]: number;
};

// @ts-expect-error science is missing!
const scores: Scores = {
  math: 95,
  english: 90,
};

scores.athletics = 100;
scores.french = 75;
scores.spanish = 70;
