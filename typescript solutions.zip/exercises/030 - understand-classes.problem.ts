import { expect, it } from "vitest";

/*
Faire fonctionner ce code
*/
class CanvasNode {
  readonly x = 0;
  readonly y = 0;
}

it("Should store some basic properties", () => {
  const canvasNode = new CanvasNode();

  expect(canvasNode.x).toEqual(0);
  expect(canvasNode.y).toEqual(0);

  // @ts-expect-error Property is readonly
  canvasNode.x = 10;

  // @ts-expect-error Property is readonly
  canvasNode.y = 20;
});
