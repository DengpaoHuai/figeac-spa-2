/*
Ici, je veux récupérer uniquement les propriétés "name" et "email" de l'objet User.
Les autres propriétés ne m'intéresse pas.
Comment faire en sorte que le type test soit correct ?
*/

import { Equal, Expect } from "../helpers";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

const fetchUser = async (): Promise<Pick<User, "email" | "name">> => {
  const response = await fetch("/api/user");
  const user = await response.json();
  return user;
};

const example = async () => {
  const user = await fetchUser();

  type test = Expect<Equal<typeof user, { name: string; email: string }>>;
};
