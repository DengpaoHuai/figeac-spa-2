/* 
Je veux pouvoir créer un objet qui représente les notes d'un élève.
Je ne connais pas d'avance toutes les matières.
Cependant, je sais que les notes seront des nombres.
*/

type Scores = {
  [subject: string]: number;
};

const scores: Scores = {};

scores.math = 95;
scores.english = 90;
scores.science = 85;
