/*
Comment typons nous le paramètre rest d'une fonction ?
*/

import { expect, it } from "vitest";
import { Equal, Expect } from "../helpers";

export function concatenate(...strings) {
  return strings.join("");
}

it("should concatenate strings", () => {
  const result = concatenate("Hello", " ", "World");
  expect(result).toEqual("Hello World");

  type test = Expect<Equal<typeof result, string>>;
});
