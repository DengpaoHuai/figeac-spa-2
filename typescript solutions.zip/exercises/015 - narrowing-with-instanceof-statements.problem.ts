const somethingDangerous = () => {
  if (Math.random() > 0.5) {
    throw new Error("Something went wrong");
  }

  return "all good";
};

try {
  somethingDangerous();
} catch (error) {
  // Comment corriger l'erreur ici ? Indice : Je n'ai pas tout dit :)
  if (error instanceof Error) {
    console.error(error.message);
  }
}
