/*
Ici, il suffit de typer chaque variable correctement.
*/

let example1: string = "Hello World!";
let example2 = 42;
let example3 = true;
let example4 = Symbol();
let example5 = 123n;
