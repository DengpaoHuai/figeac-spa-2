import { expect, it } from "vitest";

function validateUsername(username: string | null): boolean {
  // Récrire cette fonction pour faire disparaître l'erreur
  return username.length > 5;

  return false;
}

it("should return true for valid usernames", () => {
  expect(validateUsername("Pierr1234")).toBe(true);

  expect(validateUsername("Alice")).toBe(false);
  expect(validateUsername("Bob")).toBe(false);
});

it("Should return false for null", () => {
  expect(validateUsername(null)).toBe(false);
});
