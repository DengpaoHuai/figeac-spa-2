import { Equal, Expect } from "../helpers";

const returnWhatIPassIn = <T>(t: T): T => {
  return t;
};

const one = returnWhatIPassIn<1>(1);
const pierr = returnWhatIPassIn<"pierr">("pierr");

type tests = [
  Expect<Equal<typeof one, 1>>,
  Expect<Equal<typeof pierr, "pierr">>
];
