/*
Quelle doc ajouter ?
*/

const myFunction = (a: number, b: number) => {
  return a + b;
};
