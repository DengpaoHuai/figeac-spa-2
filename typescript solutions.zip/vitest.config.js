export default {
  test: {
    include: ["./zod.solutions/**/*.ts"], // Spécifiez le modèle de fichiers de tests
    passWithNoTests: true, // Passez à true pour ignorer les fichiers de tests sans tests
  },
  server: {
    // Configuration du serveur de test, si nécessaire
  },
  build: {
    // Configuration de la construction des tests, si nécessaire
  },
};
