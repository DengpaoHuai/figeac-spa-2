function log(level: "INFO" | "WARN") {
  return function loggedMethod<
    This,
    Args extends any[],
    Return,
    Fn extends (this: This, ...args: Args) => Return
  >(target: Fn, context: ClassMethodDecoratorContext<This, Fn>) {
    const methodName = String(context.name);

    function replacementMethod(this: This, ...args: Args): Return {
      console.log(`${level}: Entering method '${methodName}'.`);
      const result = target.call(this, ...args);
      console.log(`${level}: Exiting method '${methodName}'.`);
      return result;
    }

    return replacementMethod;
  };
}

function limit<T = {}>(count: number) {
  return function <
    This,
    Args extends [Array<any>, ...any[]],
    Return,
    Fn extends (this: This, ...args: Args) => Return
  >(target: Fn, context: ClassMethodDecoratorContext<This, Fn>) {
    const methodName = String(context.name);
    type Temp = This & T;
    function replacementMethod(this: Temp, ...args: Args): Return {
      const firstArg = args[0];
      if (firstArg.length > count) {
        throw new Error(
          `${methodName} cannot call with more than ${count} items`
        );
      }
      return target.call(this, ...args);
    }

    return replacementMethod;
  };
}

class Person {
  name: string;
  constructor(name: string) {
    this.name = name;
  }

  intro(guest: string) {
    console.log(`Hello ${guest}, my name is ${this.name}.`);
  }
  @limit<{ user: string }>(20) @log("WARN") introGroup(guests: string[]) {
    guests.forEach((g) => this.intro(g));
  }
}

const p = new Person("Ray");
p.introGroup(["Ben", "Amy", "Andrew"]);
