/*declare function tomorrow(d: Date): Date;

let val: any = 1;

val++;
val.toUpperCase();
val.map(val);
val.foobar = 2;
tomorrow(val);
*/

/*
declare function tomorrow(d: Date): Date;

let val: never = 1;

val++;
val.toUpperCase();
val.map(val);
val.foobar = 2;
tomorrow(val);
*/

/*
declare function tomorrow(d: Date): Date;

let val: unknown = 1;

if (typeof val === 'number') val++;
if (typeof val === 'string') val.toUpperCase();
if (Array.isArray(val)) val.map(v => v);
if (
  val &&
  typeof val === 'object' &&
  'foobar' in val &&
  typeof val.foobar === 'number'
) {
  val.foobar = 2;
}

tomorrow(val as Date); 
*/
/*
type A = number & string;
type B = boolean & null;
*/

type User = "standard" | "admin" | "superadmin";

function login(user: User) {
  switch (user) {
    case "standard":
      return true;
    case "admin":
      return true;
    default:
      const unreachable: never = user;
      throw "wrong user type";
  }
}
