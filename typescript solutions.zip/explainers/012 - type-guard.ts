function isString(test: any): test is string {
  return typeof test === "string";
}

function isNumber(test: any): test is number {
  return typeof test === "number";
}

function isBoolean(test: any): test is boolean {
  return typeof test === "boolean";
}

function isObject(test: any): test is object {
  return typeof test === "object";
}

//exemple d'utilisation

const test = Math.random();
test.toUpperCase();
if (isString(test)) {
  test.toUpperCase();
  console.log("test est une chaine de caractère");
}
