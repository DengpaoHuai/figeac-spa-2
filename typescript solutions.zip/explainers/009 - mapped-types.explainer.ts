export type Point = {
  x: number;
  y: number;
};

export type ReadonlyPoint = {
  readonly x: number;
  readonly y: number;
};

export const origin: ReadonlyPoint = {
  x: 0,
  y: 0,
};

origin.x = 100; // Should error
/*

export type Point = {
  x: number,
  y: number,
};

export type ReadonlyPoint = {
  readonly [Key in 'x' | 'y']: number
};

export const origin: ReadonlyPoint = {
  x: 0,
  y: 0,
};

origin.x = 100; // Should error
*/
/*
export type Point = {
  x: number,
  y: number,
};

export type Readonly<T> = {
  readonly [Key in keyof T]: T[Key]
};

export const origin: Readonly<Point> = {
  x: 0,
  y: 0,
};

origin.x = 100; // Should error*/
