// TS specific syntax

const routes = Object.freeze({
  home: "/",
  admin: "/admin",
  users: "/users",
});

const goToRoute = (route: "/" | "/admin" | "/users") => {};

goToRoute(routes.admin);

export {};
