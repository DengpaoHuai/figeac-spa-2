// TS specific syntax

const routes = {
  home: "/",
  admin: "/admin",
  users: "/users",
};

const goToRoute = (route: "/" | "/admin" | "/users") => {};

goToRoute(routes.admin);

// 'as const' is different from 'as'

// Alternative to enums

export {};
