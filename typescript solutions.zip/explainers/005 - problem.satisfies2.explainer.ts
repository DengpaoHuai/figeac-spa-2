//// lib
type Connection = {};

declare function createConnection(
  host: string,
  port: string,
  reconnect: boolean,
  poolSize: number
): Connection;

// app
type Config = {
  host: string;
  port: string | number;
  tryReconnect: boolean | (() => boolean);
  poolSize?: number;
};

/**
 *
 * Méthode 1 : Type guard
 *
 **/

const config: Config = {
  host: "db.myapp.com",
  port: 1234,
  tryReconnect: () => true,
};

function start() {
  let { host, port, tryReconnect, poolSize } = config;

  if (typeof port === "number") port = `${port}`;
  if (typeof tryReconnect !== "boolean") tryReconnect = tryReconnect();
  if (!poolSize) poolSize = 10;

  createConnection(host, port, tryReconnect, poolSize);
}

/**
 *
 * Méthode 2 : Type guard
 *
 **/
/*
const config = {
  host: "db.myapp.com",
  port: 1234,
  tryReconnect: () => true,
};

function start() {
  let { host, port, tryReconnect } = config;

  createConnection(host, `${port}`, tryReconnect(), 10);
}*/

export {};
