// Définir une interface pour un objet utilisateur
export interface User {
  id: number;
  name: string;
  email?: string; // Email est optionnel
}

// Définir un type pour les options de configuration
export type ConfigOptions = {
  environment: "development" | "production";
  debug: boolean;
};

// Déclaration d'une fonction avec des types spécifiques pour les paramètres et le retour
declare function initializeApp(config: ConfigOptions): void;

// Exportation d'une classe avec une méthode et un constructeur
export class ApiService {
  constructor(baseUrl: string);

  fetchData(endpoint: string, user: User): Promise<any>;
}
