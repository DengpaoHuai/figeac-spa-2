export type MyCodeInput = {
  whatever: string;
  something: boolean;
};

const runtime = () => {};

/*
Un .d.ts ne contient que des types, pas de fonctionnalités.
A quoi ça sert ? A définir des types pour des librairies qui n'en ont pas.
*/
