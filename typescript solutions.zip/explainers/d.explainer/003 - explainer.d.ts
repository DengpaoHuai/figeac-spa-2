type Example = undefined | null;
