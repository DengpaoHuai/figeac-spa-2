const num1 = "hello" as number;

const num2 = "hello" as unknown as number;

const num3 = "hello" as any as number;

const num4 = "hello" as never as number;
