interface Animal {
  name: string;
}

interface Animal {
  meow(): void;
}

const animal: Animal = {
  meow: () => {},
  name: "cat",
};
