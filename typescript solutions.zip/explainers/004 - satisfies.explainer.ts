type Color = string | { r: number; g: number; b: number };

let red: Color = "red";
const green = "green" as Color;
const blue = "blue" satisfies Color;

//green.

//blue.
