type Connection = {};

declare function createConnection(
  host: string,
  port: string,
  reconnect: boolean,
  poolSize: number
): Connection;

// app
type Config = {
  host: string;
  port: string | number;
  tryReconnect: boolean | (() => boolean);
  poolSize?: number;
};

const config = {
  host: "db.myapp.com",
  port: 1234,
  tryReconnect: () => true,
  poolSize: 10,
} as const satisfies Config;

function start() {
  let { host, port, tryReconnect, poolSize } = config;
  createConnection(host, `${port}`, tryReconnect(), poolSize);
}

export {};
