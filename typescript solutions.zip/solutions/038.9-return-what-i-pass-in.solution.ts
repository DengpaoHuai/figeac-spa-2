import { Equal, Expect } from "../helpers";

const returnWhatIPassIn = <T>(t: T) => {
  return t;
};

const one = returnWhatIPassIn(1);
const pierr = returnWhatIPassIn("pierr");

type tests = [
  Expect<Equal<typeof one, 1>>,
  Expect<Equal<typeof pierr, "pierr">>
];
