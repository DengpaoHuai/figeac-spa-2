/**
 * Adds two numbers together.
 *
 * @example
 *
 * myFunction(1, 2);
 */
const myFunction = (a: number, b: number) => {
  return a + b;
};
