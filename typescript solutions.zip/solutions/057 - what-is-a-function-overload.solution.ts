import { Equal, Expect } from "../helpers";

function returnWhatIPassIn(t: 1): 1;
function returnWhatIPassIn(t: "Pierr"): "Pierr";
function returnWhatIPassIn(t: unknown) {
  return t;
}

const one = returnWhatIPassIn(1);
const pierr = returnWhatIPassIn("Pierr");

type tests = [
  Expect<Equal<typeof one, 1>>,
  Expect<Equal<typeof pierr, "Pierr">>
];
