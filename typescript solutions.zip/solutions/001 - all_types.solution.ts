let example1: string = "Hello World!";
let example2 = 42;
let example3: boolean = true;

enum Color {
  Red,
  Green,
  Blue,
}

const colors = {
  Red: 0,
  Green: 1,
  Blue: 2,
} as const;

export type demo = string | number | boolean | symbol | bigint;
