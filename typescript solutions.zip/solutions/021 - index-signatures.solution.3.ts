const scores: Record<string, number> = {};

scores.math = 95;
scores.english = 90;
scores.science = 85;
