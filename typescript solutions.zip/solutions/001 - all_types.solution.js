"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var example1 = "Hello World!";
var example2 = 42;
var example3 = true;
var Color;
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 1] = "Green";
    Color[Color["Blue"] = 2] = "Blue";
})(Color || (Color = {}));
