type Event = {
  message: string;
};

/*
Comment corriger l'erreur ici ?
*/
const processUserMap = (eventMap: Map<string, Event>) => {
  if (eventMap.has("error")) {
    const message = eventMap.get("error").message;

    throw new Error(message);
  }
};
