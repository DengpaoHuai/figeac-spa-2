import { Equal, Expect } from "../helpers";

interface Attributes {
  firstName: string;
  lastName: string;
  age: number;
}

/*
Comment faire fonctionner ce code ? 
PS : je ne vous ai pas tout dit :)
*/

type AttributeGetters = {
  [K in keyof Attributes]: () => Attributes[K];
};

type tests = [
  Expect<
    Equal<
      AttributeGetters,
      {
        getFirstName: () => string;
        getLastName: () => string;
        getAge: () => number;
      }
    >
  >
];
