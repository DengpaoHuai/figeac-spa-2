/*
Imaginons que nous souhaitons créer une fonction qui permet d'ajouter 
un produit à notre base de données.
Nous ne connaissons pas l'id du produuit à l'avance.
Comment modifier le typage de la fonction addProduct pour faire fonctionner ce code ?
*/

interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
}

const addProduct = (productInfo: Product) => {
  // Do something with the productInfo
};

addProduct({
  name: "Book",
  price: 12.99,
  description: "A book about Dragons",
});

addProduct({
  // @ts-expect-error
  id: 1,
  name: "Book",
  price: 12.99,
  description: "A book about Dragons",
});
