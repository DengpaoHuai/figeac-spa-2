/*
Imaginons que je veuille créer une fonction qui permette de naviguer.
Cette fonction prend en paramètre une route absolue (qui commence par un /).
Comment puis-je faire pour typer cette fonction sans avoir à créer un type 
prenant en compte toutes les routes possibles ?
*/

type AbsoluteRoute = string;

const goToRoute = (route: AbsoluteRoute) => {
  // ...
};

goToRoute("/home");
goToRoute("/about");
goToRoute("/contact");

goToRoute(
  // @ts-expect-error
  "somewhere"
);
