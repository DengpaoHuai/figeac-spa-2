import { Equal, Expect } from "../helpers";

interface Attributes {
  firstName: string;
  lastName: string;
  age: number;
}

/*
Comment typer AttributeGetters ?
*/
type AttributeGetters = unknown;

type tests = [
  Expect<
    Equal<
      AttributeGetters,
      {
        firstName: () => string;
        lastName: () => string;
        age: () => number;
      }
    >
  >
];
