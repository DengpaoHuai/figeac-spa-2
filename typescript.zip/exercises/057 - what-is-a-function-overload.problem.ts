import { Equal, Expect } from "../helpers";

/**
 * Régleons ce problème avec des surcharges de fonction.
 */
const returnWhatIPassIn = (t: unknown) => {
  return t;
};

const one = returnWhatIPassIn(1);
const pierr = returnWhatIPassIn("Pierr");

type tests = [
  Expect<Equal<typeof one, 1>>,
  Expect<Equal<typeof pierr, "Pierr">>
];
