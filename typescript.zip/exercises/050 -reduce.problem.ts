import { expect, it } from "vitest";
import { Equal, Expect } from "../helpers";

const array = [
  {
    name: "John",
  },
  {
    name: "Steve",
  },
];

/*
Comment typer la fonction reduce ici ? 
*/
const obj = array.reduce((accum, item) => {
  accum[item.name] = item;
  return accum;
}, {});

it("Should resolve to an object where name is the key", () => {
  expect(obj).toEqual({
    John: {
      name: "John",
    },
    Steve: {
      name: "Steve",
    },
  });

  type tests = [Expect<Equal<typeof obj, Record<string, { name: string }>>>];
});
