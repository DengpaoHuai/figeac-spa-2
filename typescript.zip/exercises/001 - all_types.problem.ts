/*
Ici, il suffit de typer chaque variable correctement.
*/

let example1: string = "Hello World!";
let example2: string = 42;
let example3: string = true;
let example4: string = Symbol();
let example5: string = 123n;
